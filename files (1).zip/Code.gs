/**
 * Бекенд порталу Odrex. Прив'язаний до Google таблиці з трьома вкладками:
 * Items (id, category, title, code, url, audience, note, updatedAt)
 *   audience зберігається як рядок через кому, наприклад: callcenter,branch-roz,branch-fil
 *   або просто: all
 * Branches (id, name, passcode)
 * Settings (key, value) — рядки callcenterPasscode і adminPasscode
 */

function respond(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function getSettings_() {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Settings');
  var data = sheet.getDataRange().getValues();
  var settings = {};
  for (var i = 1; i < data.length; i++) {
    if (data[i][0]) settings[data[i][0]] = data[i][1];
  }
  return settings;
}

function getBranches_() {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Branches');
  var data = sheet.getDataRange().getValues();
  var branches = [];
  for (var i = 1; i < data.length; i++) {
    if (data[i][0]) branches.push({ id: data[i][0], name: data[i][1], passcode: data[i][2] });
  }
  return branches;
}

function getItems_() {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Items');
  var data = sheet.getDataRange().getValues();
  var items = [];
  for (var i = 1; i < data.length; i++) {
    if (!data[i][0]) continue;
    items.push({
      id: data[i][0], category: data[i][1], title: data[i][2], code: data[i][3],
      url: data[i][4], audience: data[i][5], note: data[i][6], updatedAt: data[i][7]
    });
  }
  return items;
}

function resolveRole_(code) {
  if (!code) return null;
  var settings = getSettings_();
  if (code === settings.adminPasscode) return { type: 'admin', name: 'Адміністратор порталу' };
  if (code === settings.callcenterPasscode) return { type: 'callcenter', name: 'Кол центр' };
  var branch = getBranches_().filter(function (b) { return b.passcode === code; })[0];
  if (branch) return { type: 'branch', id: branch.id, name: branch.name };
  return null;
}

function verifyAdmin_(code) {
  var settings = getSettings_();
  return !!code && code === settings.adminPasscode;
}

function audienceTags_(audience) {
  return (audience || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
}

function itemVisible_(item, role) {
  if (role.type === 'admin') return true;
  var tags = audienceTags_(item.audience);
  if (tags.indexOf('all') > -1) return true;
  if (role.type === 'callcenter') return tags.indexOf('callcenter') > -1;
  if (role.type === 'branch') return tags.indexOf(role.id) > -1;
  return false;
}

function getDataForCode_(code) {
  var role = resolveRole_(code);
  if (!role) return { error: 'invalid_code' };
  var items = getItems_().filter(function (it) { return itemVisible_(it, role); });
  var branches = getBranches_().map(function (b) {
    return role.type === 'admin' ? b : { id: b.id, name: b.name };
  });
  return { role: role, items: items, branches: branches };
}

function saveItem_(item) {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Items');
  var audience = Array.isArray(item.audience) ? item.audience.join(',') : item.audience;
  if (item.id) {
    var data = sheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === item.id) {
        sheet.getRange(i + 1, 1, 1, 8).setValues([[item.id, item.category, item.title, item.code, item.url, audience, item.note, Date.now()]]);
        return { ok: true, id: item.id };
      }
    }
  }
  var newId = 'item-' + Date.now();
  sheet.appendRow([newId, item.category, item.title, item.code, item.url, audience, item.note, Date.now()]);
  return { ok: true, id: newId };
}

function deleteItem_(id) {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Items');
  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] === id) { sheet.deleteRow(i + 1); return { ok: true }; }
  }
  return { error: 'not_found' };
}

function addBranch_(name) {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Branches');
  var id = 'branch-' + Date.now();
  var passcode = Math.random().toString(36).slice(2, 8);
  sheet.appendRow([id, name, passcode]);
  return { ok: true, id: id, passcode: passcode };
}

function removeBranch_(id) {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Branches');
  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] === id) { sheet.deleteRow(i + 1); return { ok: true }; }
  }
  return { error: 'not_found' };
}

function updateBranchPasscode_(id, passcode) {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Branches');
  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] === id) { sheet.getRange(i + 1, 3).setValue(passcode); return { ok: true }; }
  }
  return { error: 'not_found' };
}

function updateSetting_(key, value) {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Settings');
  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] === key) { sheet.getRange(i + 1, 2).setValue(value); return { ok: true }; }
  }
  sheet.appendRow([key, value]);
  return { ok: true };
}

function doGet(e) {
  var code = (e.parameter && e.parameter.code) || '';
  return respond(getDataForCode_(code));
}

function doPost(e) {
  var body;
  try {
    body = JSON.parse(e.postData.contents);
  } catch (err) {
    return respond({ error: 'bad_request' });
  }
  if (!verifyAdmin_(body.adminCode)) return respond({ error: 'unauthorized' });

  var result;
  switch (body.action) {
    case 'saveItem': result = saveItem_(body.item); break;
    case 'deleteItem': result = deleteItem_(body.id); break;
    case 'addBranch': result = addBranch_(body.name); break;
    case 'removeBranch': result = removeBranch_(body.id); break;
    case 'updateBranchPasscode': result = updateBranchPasscode_(body.id, body.passcode); break;
    case 'updateSetting': result = updateSetting_(body.key, body.value); break;
    default: result = { error: 'unknown_action' };
  }
  return respond(result);
}
